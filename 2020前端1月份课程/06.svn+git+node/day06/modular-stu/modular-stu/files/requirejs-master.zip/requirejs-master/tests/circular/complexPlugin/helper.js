define(function (require, exports) {
    //Create circular dependency here
    var main = require('main');

    exports.name = 'helper';
});
