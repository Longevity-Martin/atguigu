define(["require", "exports", "module", "c"], function(require, exports, module) {
exports.foo = require('c').foo;

});
