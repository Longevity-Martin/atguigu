define(function (require) {
    if (typeof obj !== 'undefined') {
        obj.require('bad');
    }
    return {
        name: 'c'
    };
});

