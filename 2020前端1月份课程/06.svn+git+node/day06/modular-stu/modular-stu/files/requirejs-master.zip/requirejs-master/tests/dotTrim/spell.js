define(['./sub/ext'], function(ext) {
  return {
    name: 'spell',
    ext: ext
  };
});
