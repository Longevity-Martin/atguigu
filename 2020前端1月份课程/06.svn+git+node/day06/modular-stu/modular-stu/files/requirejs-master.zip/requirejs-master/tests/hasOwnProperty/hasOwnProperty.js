define({
    name: 'hasOwnProperty'
});