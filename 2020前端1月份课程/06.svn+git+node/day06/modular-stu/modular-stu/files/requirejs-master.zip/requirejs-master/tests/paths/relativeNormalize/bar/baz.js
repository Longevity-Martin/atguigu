define(function (require) {
    return {
        name: 'baz',
        foo: require('./foo')
    };
});
