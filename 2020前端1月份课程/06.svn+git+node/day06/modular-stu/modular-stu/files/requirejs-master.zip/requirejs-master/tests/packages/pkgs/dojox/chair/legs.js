define({
    name: 'dojox/chair/legs'
});
