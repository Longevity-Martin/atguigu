define({
    name: 'a'
});
