define('third', {
    name: 'third'
});
