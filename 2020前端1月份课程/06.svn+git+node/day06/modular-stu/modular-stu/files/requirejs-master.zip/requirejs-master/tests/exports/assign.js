define("assign",
            ["require", "exports", "module"],
            function (require, exports, module) {
    module.exports = "assign";
});
