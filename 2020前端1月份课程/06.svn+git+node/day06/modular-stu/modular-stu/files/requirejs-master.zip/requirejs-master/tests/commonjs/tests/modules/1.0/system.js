define({
    stdio: {
        //Funky list args to appease Safari
        print: function (a, b) {
            console.log(a, b);
        }
    }
});
