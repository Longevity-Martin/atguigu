define(["f", ".", "js"]);
