define(function(require) {

  require('./m').count = 10

});

