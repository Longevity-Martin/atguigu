define(function (require, exports) {

  exports.name = 'a'

  exports.foo = function() {
    return 'foo'
  }

});
