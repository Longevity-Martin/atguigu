describe('basicAuth', function () {
  setupBasicAuthTest();
});
